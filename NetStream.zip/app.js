// ==========================================
// 1. CONFIGURAÇÕES GERAIS E VARIÁVEIS
// ==========================================
var XT = {
	baseUrl : "",
	username : "",
	password : ""
};
var cache = {
	liveCats : [],
	movieCats : [],
	seriesCats : []
};

var focusArea = "login", loginFocus = 0;
var sideMenuIndex = 1, catIndex = 0, gridIndex = 0, detailsFocus = 0;
var currentType = "live", currentView = "categories", currentCategoryId = null;
var currentItems = [], displayedItems = [], selectedItem = null, currentCategories = [], seriesCache = null;
var playerOrigin = null;      // "details" ou "episodio"
var lastSeriesItem = null;    // guarda a série aberta nos detalhes
var loginBox = document.getElementById("login"),
    codeEl = document.getElementById("code"),
    userEl = document.getElementById("username"),
    passEl = document.getElementById("password"),
    loginError = document.getElementById("loginError");
var loadingScreen = document.getElementById("loadingScreen"), loadingStatus = document
		.getElementById("loadingStatus");
var appArea = document.getElementById("appArea");
var playerBox = document.getElementById("player"), videoEl = document
		.getElementById("video"), detailsBox = document
		.getElementById("details");
var searchEl = document.getElementById("search"); // Novo campo de busca

// ==========================================
// 2. REDE E LOGIN
// ==========================================
function normalizeBaseUrl(url) {
	var t = (url || "").trim();
	if (t.charAt(t.length - 1) === '/')
		t = t.substring(0, t.length - 1);
	return t;
}
function xtreamUrl(act) {
	return XT.baseUrl + "/player_api.php?username=" + XT.username
			+ "&password=" + XT.password + "&action=" + act;
}

function safeJson(url, cbSucesso, cbErro) {
	try {
		var xhr = new XMLHttpRequest();
		xhr.open("GET", url, true);
		var finalizado = false;

		// MÁGICA DE RESISTÊNCIA: Aumentamos de 30 para 60 segundos (60000ms)
		// Isso dá fôlego para a TV baixar a lista gigante de filmes do
		// servidor!
		var timer = setTimeout(function() {
			if (!finalizado) {
				finalizado = true;
				xhr.abort();
				cbErro("Timeout");
			}
		}, 60000);

		xhr.onload = function() {
			if (finalizado)
				return;
			finalizado = true;
			clearTimeout(timer);
			if (xhr.status >= 200 && xhr.status < 300) {
				try {
					var data = JSON.parse(xhr.responseText);
					cbSucesso(data);
				} catch (e) {
					cbErro("Erro JSON");
				}
			} else {
				cbErro("Erro Status");
			}
		};
		xhr.onerror = function() {
			if (finalizado)
				return;
			finalizado = true;
			clearTimeout(timer);
			cbErro("Erro Rede");
		};
		xhr.send();
	} catch (e) {
		cbErro("Erro Fatal");
	}
}

function doLogin() {
	loginError.textContent = "Buscando código...";

	var code = codeEl ? codeEl.value.trim() : "";
	var user = userEl.value.trim();
	var pass = passEl.value.trim();

	if (!code || !user || !pass) {
		loginError.textContent = "Preencha código, usuário e senha!";
		return;
	}

	safeJson(
		"https://raw.githubusercontent.com/Leasdo022/satcodigo-config/refs/heads/main/config.json",
		function(config) {
			if (!config || !config[code] || !config[code].url) {
				loginError.textContent = "Código inválido!";
				return;
			}

			XT.baseUrl = normalizeBaseUrl(config[code].url);
			XT.username = user;
			XT.password = pass;

			loginError.textContent = "Conectando...";

			safeJson(xtreamUrl(""), function(d) {
				if (d && d.user_info && d.user_info.auth == 1) {
					localStorage.setItem("net_code", code);
					localStorage.setItem("net_user", user);
					localStorage.setItem("net_pass", pass);

					entrarNoApp();
				} else {
					loginError.textContent = "Usuário ou senha incorretos!";
				}
			}, function() {
				loginError.textContent = "Erro ao conectar ao servidor deste código!";
			});
		},
		function() {
			loginError.textContent = "Erro ao buscar códigos no GitHub!";
		}
	);
}

	// --- A MÁGICA DO GITHUB ENTRA AQUI ---
	loginError.textContent = "Buscando servidores...";

	// O app vai no seu GitHub puxar a lista atualizada
	safeJson(
			"https://raw.githubusercontent.com/Leasdo022/satcodigo-config/refs/heads/main/config.json",
			function(listaDoGithub) {
				// Sucesso! Vai testar a conexão usando os servidores do GitHub
				loginError.textContent = "Conectando aos servidores...";
				testar(listaDoGithub, 0);
			}, function() {
				// Se o GitHub falhar (sem internet ou bloqueado), usa a
				// fallbackList como Plano B
				console.log("Falha ao ler o GitHub. Usando lista de backup.");
				testar(fallbackList, 0);
			});

// ==========================================
// 3. CARREGAMENTO E HOME
// ==========================================
function entrarNoApp() {
	loginBox.style.display = "none";
	loadingScreen.style.display = "flex";
	loadAllData();
}

function loadAllData() {
	var progresso = 0;
	function conferirFinalizacao() {
		progresso++;
		if (progresso === 3) {
			loadingStatus.textContent = "Conteúdo Carregado!";
			setTimeout(exibirNovaHome, 800);
		}
	}
	loadingStatus.textContent = "Buscando Canais Ao Vivo...";
	safeJson(xtreamUrl("get_live_categories"), function(d) {
		cache.liveCats = d || [];
		loadingStatus.textContent = "Buscando Filmes...";
		conferirFinalizacao();
	}, conferirFinalizacao);
	safeJson(xtreamUrl("get_vod_categories"), function(d) {
		cache.movieCats = d || [];
		loadingStatus.textContent = "Buscando Séries...";
		conferirFinalizacao();
	}, conferirFinalizacao);
	safeJson(xtreamUrl("get_series_categories"), function(d) {
		cache.seriesCats = d || [];
		conferirFinalizacao();
	}, conferirFinalizacao);
}

function exibirNovaHome() {
	loadingScreen.style.display = "none";
	document.body.classList.remove("tela-login");
	if (appArea)
		appArea.style.display = "block";
	sideMenuIndex = 1;
	showCategories("live");
	focusArea = "catList";
	updateFocus();
}

// ==========================================
// 4. COLUNAS E BUSCA NO SERVIDOR
// ==========================================
var ultimoTermo = "";

function executarBusca() {
	if (!searchEl)
		return;
	var query = searchEl.value.toLowerCase().trim();
	if (!query)
		return;

	if (query === ultimoTermo
			&& (focusArea === "details" || focusArea === "player"))
		return;
	ultimoTermo = query;

	searchEl.blur(); // Fecha o teclado

	// MÁGICA SAMSUNG: Foge da área de busca instantaneamente!
	// Assim, o "OK fantasma" da TV vai cair no vazio e não vai reabrir o
	// teclado.
	focusArea = "grid";
	displayedItems = []; // Limpa a memória pro OK não clicar em filme errado
	updateFocus();

	var grid = document.getElementById("channelList");
	grid.innerHTML = '<div style="padding:24px; font-size:20px; color:#007bff;">Pesquisando no servidor...</div>';

	var action = currentType === "live" ? "get_live_streams"
			: (currentType === "series" ? "get_series" : "get_vod_streams");

	safeJson(
			xtreamUrl(action),
			function(todosItens) {
				var listaCompleta = [];

				// ESCUDO PROTETOR: Garante que a lista não venha quebrada do
				// servidor
				if (Array.isArray(todosItens)) {
					listaCompleta = todosItens;
				} else if (todosItens && typeof todosItens === 'object') {
					// Se o servidor mandar formato de objeto, a gente converte
					// pra lista
					for ( var key in todosItens) {
						if (todosItens.hasOwnProperty(key))
							listaCompleta.push(todosItens[key]);
					}
				}

				currentItems = listaCompleta.filter(function(item) {
					if (!item)
						return false;
					var name = item.name || item.title || "";
					return name.toLowerCase().indexOf(query) > -1;
				});

				renderGrid();

				if (focusArea !== "details" && focusArea !== "player") {
					focusArea = "grid";
					gridIndex = 0;
					updateFocus();
				}
			},
			function() {
				if (focusArea !== "details" && focusArea !== "player") {
					grid.innerHTML = '<div style="padding:24px; color:red;">Erro ao pesquisar. A lista de filmes é muito grande para a conexão.</div>';
				}
			});
}
if (searchEl) {
	searchEl.addEventListener("change", executarBusca);
	searchEl.addEventListener("keydown", function(e) {
		// 13 é a LG/WebOS | 65376 é o código secreto do botão "Done" da Samsung
		if (e.keyCode === 13 || e.keyCode === 65376) {
			e.preventDefault();
			executarBusca();
		}
	});
}
function showCategories(type) {
	currentType = type;
	gridIndex = 0;
	catIndex = 0;
	// Cria a Busca e os Favoritos Dinamicamente
	var searchCat = {
		category_id : "search",
		category_name : "Buscar"
	};
	var favCat = {
		category_id : "favs",
		category_name : "Favoritos"
	};

	if (type === "live")
		currentCategories = [ searchCat, favCat ].concat(cache.liveCats);
	if (type === "movies")
		currentCategories = [ searchCat, favCat ].concat(cache.movieCats);
	if (type === "series")
		currentCategories = [ searchCat, favCat ].concat(cache.seriesCats);

	renderCategoryList();
	if (currentCategories.length > 1) {
		openCategory("favs", false);
		catIndex = 1;
	}
}

function renderCategoryList() {
	var lista = document.getElementById("categoryList");
	if (!lista)
		return;
	lista.innerHTML = "";
	currentCategories.forEach(function(cat) {
		var div = document.createElement("div");
		div.className = "cat-item";
		var icon = "";
		if (cat.category_id === "search")
			icon = '🔍 ';
		else if (cat.category_id === "favs")
			icon = '⭐ ';
		div.innerHTML = icon + (cat.category_name || cat.name);
		lista.appendChild(div);
	});
}

function openCategory(id, pularParaGrade) {
	currentCategoryId = id;
	currentView = "streams";
	gridIndex = 0;
	var grid = document.getElementById("channelList");

	// Mostra/Esconde a Barra de Pesquisa
	if (id === "search") {
		if (searchEl) {
			searchEl.style.display = "block";
			searchEl.value = "";
		}
		grid.innerHTML = '<div style="padding:24px; color:#aaa;">Aperte para Direita e digite o nome...</div>';
		currentItems = [];
		if (pularParaGrade) {
			focusArea = "search";
			updateFocus();
		}
		return;
	} else {
		if (searchEl)
			searchEl.style.display = "none";
	}

	if (grid)
		grid.innerHTML = '<div style="padding:24px; font-size:20px; color:#007bff;">Buscando conteúdos...</div>';

	if (id === "favs") {
		var allFavs = getFavs();
		currentItems = allFavs.filter(function(f) {
			return f.savedType === currentType;
		});
		renderGrid();
		if (pularParaGrade && currentItems.length > 0)
			focusArea = "grid";
		updateFocus();
		return;
	}

	var url = currentType === "live" ? xtreamUrl("get_live_streams")
			+ "&category_id=" + id : xtreamUrl("get_vod_streams")
			+ "&category_id=" + id;
	if (currentType === "series")
		url = xtreamUrl("get_series") + "&category_id=" + id;

	safeJson(url, function(d) {
		currentItems = d || [];
		renderGrid();
		if (pularParaGrade && currentItems.length > 0)
			focusArea = "grid";
		updateFocus();
	}, function() {
		currentItems = [];
		renderGrid();
		updateFocus();
	});
}

function renderGrid() {
	var grid = document.getElementById("channelList");
	if (!grid)
		return;
	grid.innerHTML = "";
	displayedItems = currentItems;
	if (!displayedItems || displayedItems.length === 0) {
		grid.innerHTML = '<div style="padding:24px;">Nenhum conteúdo encontrado.</div>';
		return;
	}

	displayedItems
			.forEach(function(item) {
				var card = document.createElement("div");
				var title = item.name || item.title || "Sem Título";
				var bg = item.stream_icon || item.cover || "";

				if (currentType === "live") {
					// TV Ao Vivo: Desenha Retângulo com a Logo do Canal
					// (Atualizado)
					card.className = "live-card channel-item";

					// Busca a logo no servidor (pode ser 'stream_icon' ou
					// 'icon')
					var liveBg = item.stream_icon || item.icon || "";
					if (liveBg) {
						card.style.backgroundImage = "url('" + liveBg + "')";
					}
					// Coloca o nome do canal por cima com a sombra
					card.innerHTML = '<div class="live-overlay"><div class="live-title">'
							+ title + '</div></div>';
				} else {
					card.className = "movie-card channel-item";
					card.style.backgroundImage = bg ? "url('" + bg + "')"
							: "none";
					card.innerHTML = '<div class="movie-title">' + title
							+ '</div>';
				}
				grid.appendChild(card);
			});
}

// ==========================================
// 5. SÉRIES, DETALHES E PLAYER
// ==========================================
function openSeries(id) {
	currentView = "temporada";
	gridIndex = 0;
	focusArea = "grid";

	if (appArea) appArea.style.display = "block";
	if (detailsBox) detailsBox.style.display = "none";

	document.getElementById("channelList").innerHTML =
		'<div style="padding:24px; color:#007bff;">Buscando Temporadas...</div>';

	safeJson(xtreamUrl("get_series_info") + "&series_id=" + id, function(d) {
		seriesCache = d;

		var eps = (d && d.episodes) ? d.episodes : {};
		var sKeys = Object.keys(eps).sort(function(a, b) {
			return Number(a) - Number(b);
		});

		currentItems = sKeys.map(function(s) {
			return {
				is_season: true,
				name: "Temporada " + s,
				episodes: eps[s]
			};
		});

		renderGrid();
		updateFocus();
	}, function() {
		currentItems = [];
		renderGrid();
		updateFocus();
	});
}

function openSeason(item) {
	currentView = "episodio";
	gridIndex = 0;
	focusArea = "grid";

	currentItems = (item.episodes || []).map(function(ep) {
		return {
			is_episode: true,
			name: ep.title || ("Episódio " + ep.episode_num),
			stream_id: ep.id,
			container_extension: ep.container_extension
		};
	});

	renderGrid();
	updateFocus();
}

// ==========================================
// ABERTURA DE DETALHES E SINOPSE
// ==========================================
function openDetails(item) {
	selectedItem = item;
	if (currentType === "series") lastSeriesItem = item;
	focusArea = "details";
	detailsFocus = 0;
	if (appArea)
		appArea.style.display = "none";
	if (detailsBox)
		detailsBox.style.display = "block";

	document.getElementById("detailsTitle").textContent = item.name
			|| item.title || "Sem título";
	document.getElementById("detailsDesc").textContent = currentType === "live" ? "Transmissão Ao Vivo"
			: "Buscando sinopse...";

	// Puxa a capa pequena primeiro para não ficar vazio
	var bg = item.stream_icon || item.cover || "";
	document.getElementById("detailsPoster").style.backgroundImage = bg ? "url('"
			+ bg + "')"
			: "none";

	var isSer = !!item.series_id || currentType === "series";
	var botoes = document.querySelectorAll(".details-btn");
	if (botoes.length > 0)
		botoes[0].innerHTML = isSer ? "▶ Ver Episódios" : "▶ Assistir";

	var btnFav = document.getElementById("btnFav");
	if (btnFav)
		btnFav.innerHTML = isFav(item.stream_id || item.series_id) ? "🌟 Remover"
				: "⭐ Favoritar";

	updateFocus();
	// MÁGICA NETSTREAM: Busca o Guia de Programação (EPG) para Canais Ao Vivo
	if (currentType === "live") {
		document.getElementById("detailsDesc").innerHTML = "Buscando programação atual...";
		var epgUrl = xtreamUrl("get_short_epg") + "&stream_id="
				+ item.stream_id;

		safeJson(
				epgUrl,
				function(data) {
					// Confere se o servidor mandou a lista
					if (data && data.epg_listings
							&& data.epg_listings.length > 0) {

						// Função rápida para traduzir o texto maluco do
						// servidor
						function decodificar(texto) {
							if (!texto)
								return "";
							try {
								return decodeURIComponent(escape(atob(texto)));
							} catch (e) {
								return texto;
							}
						}

						// 1. PROGRAMA ATUAL (Índice 0)
						var progAtual = data.epg_listings[0];
						var tituloAtual = decodificar(progAtual.title);
						var descAtual = decodificar(progAtual.description);

						// Monta a primeira parte (Agora)
						var textoFinal = "<strong style='color:#fff;'>▶ AGORA:</strong> "
								+ tituloAtual;

						// Se tiver sinopse, coloca menor e cinza. Se não, só
						// pula linha.
						if (descAtual) {
							textoFinal += "<br><span style='font-size:18px; color:#aaa;'>"
									+ descAtual + "</span><br><br>";
						} else {
							textoFinal += "<br><br>";
						}

						// 2. PRÓXIMO PROGRAMA (Índice 1) - Só aparece se o
						// servidor mandar
						if (data.epg_listings.length > 1) {
							var progSeguinte = data.epg_listings[1];
							var tituloSeguinte = decodificar(progSeguinte.title);

							textoFinal += "<strong style='color:#007bff;'>⏭️ A SEGUIR:</strong> "
									+ tituloSeguinte;
						}

						// Joga tudo na tela!
						document.getElementById("detailsDesc").innerHTML = textoFinal;

					} else {
						document.getElementById("detailsDesc").innerHTML = "Guia de programação não disponível neste canal.";
					}
				},
				function() {
					document.getElementById("detailsDesc").innerHTML = "Transmissão Ao Vivo";
				});

		return; // Garante que o código de filmes não rode por engano aqui
	}

	// Busca as informações completas no servidor
	var url = isSer ? xtreamUrl("get_series_info") + "&series_id="
			+ (item.series_id || item.id) : xtreamUrl("get_vod_info")
			+ "&vod_id=" + item.stream_id;

	safeJson(
			url,
			function(d) {
				// Confere se o usuário ainda está na mesma tela
				if (selectedItem === item) {
					var desc = "Sinopse não disponível neste servidor.";

					// A MÁGICA: Procura a sinopse em todas as gavetas possíveis
					// da API
					if (d && d.info && d.info.plot) {
						desc = d.info.plot;
					} else if (d && d.movie_data && d.movie_data.plot) {
						desc = d.movie_data.plot;
					}
					document.getElementById("detailsDesc").textContent = desc;

					// BÔNUS: Se a API mandar uma capa em HD, substitui a capa
					// borrada!
					var betterCover = (d && d.info && (d.info.cover || d.info.movie_image))
							|| "";
					if (betterCover) {
						document.getElementById("detailsPoster").style.backgroundImage = "url('"
								+ betterCover + "')";
					}
				}
			},
			function() {
				document.getElementById("detailsDesc").textContent = "Erro ao conectar com o servidor para buscar a sinopse.";
			});
}

function closeDetails() {
	if (detailsBox)
		detailsBox.style.display = "none";
	if (appArea)
		appArea.style.display = "block";
	focusArea = "grid";
	updateFocus();
}

function playStream(item) {
	selectedItem = item;

	// Guarda a origem correta do player
	if (item && item.is_episode) {
		playerOrigin = "episodio";
	} else {
		playerOrigin = "details";
	}

	if (appArea)
		appArea.style.display = "none";
	if (detailsBox)
		detailsBox.style.display = "none";
	if (playerBox)
		playerBox.style.display = "block";

	document.getElementById("playerTitle").textContent =
		item.name || item.title || "Assistindo...";

	var t = currentType === "fav" ? item.savedType : currentType;
	var ext = item.container_extension || (t === "live" ? "m3u8" : "mp4");
	var url = XT.baseUrl + (t === "live" ? "/live/" : "/movie/") +
		XT.username + "/" + XT.password + "/" + item.stream_id + "." + ext;

	if (item.is_episode || t === "series") {
		url = XT.baseUrl + "/series/" + XT.username + "/" + XT.password + "/" +
			(item.stream_id || item.id) + "." + ext;
	}

	videoEl.src = url;
	videoEl.type = (t === "live" || ext === "m3u8")
		? "application/vnd.apple.mpegurl"
		: "video/mp4";

	try {
		videoEl.load();
		videoEl.play();
	} catch (e) {}

	focusArea = "player";
	updateFocus();
}
function stopPlayer() {
	try {
		videoEl.pause();
		videoEl.removeAttribute("src");
		videoEl.load();
	} catch (e) {}

	if (playerBox)
		playerBox.style.display = "none";

	// PLAYER -> EPISÓDIOS
	if (playerOrigin === "episodio") {
		if (appArea) appArea.style.display = "block";
		if (detailsBox) detailsBox.style.display = "none";

		currentView = "episodio";
		focusArea = "grid";
		updateFocus();
		return;
	}

	// PLAYER -> DETALHES
	if (detailsBox) detailsBox.style.display = "block";
	if (appArea) appArea.style.display = "none";

	focusArea = "details";
	detailsFocus = 0;
	updateFocus();
}

function getFavKey() {
	return "netstream_favs_" + (XT.username || "user");
}
function getFavs() {
	return JSON.parse(localStorage.getItem(getFavKey()) || "[]");
}
function isFav(id) {
	return getFavs().some(function(f) {
		return (f.stream_id || f.series_id) == id;
	});
}
function toggleFav(item) {
	if (!item)
		return;
	var favs = getFavs(), id = item.stream_id || item.series_id, idx = -1;
	for (var i = 0; i < favs.length; i++) {
		if ((favs[i].stream_id || favs[i].series_id) == id) {
			idx = i;
			break;
		}
	}
	if (idx > -1)
		favs.splice(idx, 1);
	else {
		item.savedType = currentType;
		favs.push(item);
	}
	localStorage.setItem(getFavKey(), JSON.stringify(favs));
}

// ==========================================
// 6. NAVEGAÇÃO DO CONTROLE REMOTO
// ==========================================
function updateFocus() {
	var todos = document.querySelectorAll('.focus');
	for (var i = 0; i < todos.length; i++)
		todos[i].classList.remove('focus');

	var estaNoTexto = (focusArea === "login" && (loginFocus === 0 || loginFocus === 1 || loginFocus === 2));
	if (!estaNoTexto && focusArea !== "search" && document.activeElement
			&& document.activeElement.blur)
		document.activeElement.blur();

	if (focusArea === "login") {
    var campos = [
        codeEl,
        userEl,
        passEl,
        document.getElementById("btnLogin"),
        document.getElementById("btnSairLogin")
    ];

    if (campos[loginFocus]) {
        campos[loginFocus].classList.add("focus");
        if (estaNoTexto) campos[loginFocus].focus();
    }
}
	else if (focusArea === "sideMenu") {
		var menus = document.querySelectorAll(".menu-item");
		if (menus[sideMenuIndex])
			menus[sideMenuIndex].classList.add("focus");
	} else if (focusArea === "catList") {
		var cats = document.querySelectorAll("#categoryList .cat-item");
		if (cats[catIndex]) {
			cats[catIndex].classList.add("focus");
			cats[catIndex].scrollIntoView({
				block : "center",
				behavior : "smooth"
			});
		}
	} else if (focusArea === "search") {
		if (searchEl)
			searchEl.classList.add("focus");
	} else if (focusArea === "grid") {
		var items = document.querySelectorAll(".channel-item");
		if (items[gridIndex]) {
			items[gridIndex].classList.add("focus");
			items[gridIndex].scrollIntoView({
				block : "center",
				behavior : "smooth"
			});
		}
	} else if (focusArea === "details") {
		var botoes = document.querySelectorAll(".details-btn");
		if (botoes[detailsFocus])
			botoes[detailsFocus].classList.add("focus");
	}
}

document.addEventListener("keydown", function(e) {
	var k = e.keyCode || e.which;
	var keyName = e.key || "";

	if ([37, 38, 39, 40, 13, 10009, 461, 27, 8].indexOf(k) > -1) {
		if (document.activeElement && document.activeElement.tagName !== "INPUT") {
			e.preventDefault();
			e.stopPropagation();
			e.stopImmediatePropagation();
		}
	}

	// ==========================================
	// BOTÃO VOLTAR
	// ==========================================
	if (k === 10009 || k === 461 || k === 27 || k === 8 || keyName === "GoBack" || keyName === "Back") {

		if (focusArea === "login" && k === 8) return;

		if (focusArea === "search") {
			if (k === 8) return;
			if (searchEl) searchEl.blur();
			focusArea = "catList";
			updateFocus();
			return;
		}

		if (e.preventDefault) e.preventDefault();

		// PLAYER -> EPISÓDIOS ou DETALHES
		if (focusArea === "player") {
			stopPlayer();
			return;
		}

		// DETALHES -> CATEGORIAS
		if (focusArea === "details") {
			closeDetails();
			focusArea = "catList";
			updateFocus();
			return;
		}

		// GRID
		if (focusArea === "grid") {

			// EPISÓDIOS -> TEMPORADAS
			if (currentView === "episodio") {
				currentView = "temporada";
				gridIndex = 0;

				if (seriesCache && seriesCache.episodes) {
					var eps = seriesCache.episodes;
					var sKeys = Object.keys(eps).sort(function(a, b) {
						return Number(a) - Number(b);
					});

					currentItems = sKeys.map(function(s) {
						return {
							is_season: true,
							name: "Temporada " + s,
							episodes: eps[s]
						};
					});
				}

				renderGrid();
				focusArea = "grid";
				updateFocus();
				return;
			}

			// TEMPORADAS -> DETALHES
			if (currentView === "temporada") {
				currentView = "streams";

				if (appArea) appArea.style.display = "none";
				if (detailsBox) detailsBox.style.display = "block";

				if (lastSeriesItem) {
					selectedItem = lastSeriesItem;
					document.getElementById("detailsTitle").textContent =
						selectedItem.name || selectedItem.title || "Sem título";
				}

				focusArea = "details";
				detailsFocus = 0;
				updateFocus();
				return;
			}

			// GRID NORMAL -> CATEGORIAS
			focusArea = "catList";
			updateFocus();
			return;
		}

		if (focusArea === "catList") {
			focusArea = "sideMenu";
			updateFocus();
			return;
		}

		if (focusArea === "sideMenu" || focusArea === "login") {
			window.telaAntesDeSair = focusArea;
			var popup = document.getElementById("exitPopup");
			if (popup) popup.style.display = "flex";
			focusArea = "exitPopup";
			window.exitFocus = 1;
			updateFocus();
			return;
		}

		if (focusArea === "exitPopup") {
			var popup2 = document.getElementById("exitPopup");
			if (popup2) popup2.style.display = "none";
			focusArea = window.telaAntesDeSair || "login";
			updateFocus();
			return;
		}
	}

	// ==========================================
	// LOGIN
	// ==========================================
	if (focusArea === "login") {
	if (k === 40) {
		if (loginFocus < 4) loginFocus++;
	}
	else if (k === 38) {
		if (loginFocus > 0) loginFocus--;
	}
	else if (k === 13) {
		if (loginFocus === 0 && codeEl) codeEl.focus();
		else if (loginFocus === 1) userEl.focus();
		else if (loginFocus === 2) passEl.focus();
		else if (loginFocus === 3) doLogin();
		else if (loginFocus === 4) window.close();
		return;
	}
	updateFocus();
	return;
}

	// ==========================================
	// MENU LATERAL
	// ==========================================
	else if (focusArea === "sideMenu") {
		var totalMenus = document.querySelectorAll(".menu-item").length;

		if (k === 40) {
			if (sideMenuIndex < totalMenus - 1) sideMenuIndex++;
		}
		else if (k === 38) {
			if (sideMenuIndex > 0) sideMenuIndex--;
		}
		else if (k === 39) {
			focusArea = "catList";
		}
		else if (k === 13) {
			if (sideMenuIndex === 1) showCategories("live");
			else if (sideMenuIndex === 2) showCategories("movies");
			else if (sideMenuIndex === 3) showCategories("series");
			else if (sideMenuIndex === 4) {
				try {
					window.close();
				} catch (e) {
					location.href = "about:blank";
				}
			}
		}
	}

	// ==========================================
	// CATEGORIAS
	// ==========================================
	else if (focusArea === "catList") {
		if (k === 40) {
			if (catIndex < currentCategories.length - 1) catIndex++;
		}
		else if (k === 38) {
			if (catIndex > 0) catIndex--;
		}
		else if (k === 37) {
			focusArea = "sideMenu";
		}
		else if (k === 39 || k === 13) {
			var id = currentCategories[catIndex].category_id
				|| currentCategories[catIndex].id
				|| currentCategories[catIndex].num;

			openCategory(id, true);

			if (id === "search") {
				focusArea = "search";
				if (k === 13 && searchEl) searchEl.focus();
			}
			else if (displayedItems.length > 0) {
				focusArea = "grid";
				gridIndex = 0;
			}
		}
	}

	// ==========================================
	// BUSCA
	// ==========================================
	else if (focusArea === "search") {
		if (k === 40) {
			focusArea = "grid";
			updateFocus();
			return;
		}
		else if (k === 37) {
			if (searchEl) searchEl.blur();
			focusArea = "catList";
			updateFocus();
			return;
		}
		else if (k === 13) {
			if (document.activeElement === searchEl) executarBusca();
			else if (searchEl) searchEl.focus();
			return;
		}
	}

	// ==========================================
	// GRID
	// ==========================================
	else if (focusArea === "grid") {
		var cols = (currentType === "live") ? 6 : 8;

		if (k === 39) {
			if (gridIndex < displayedItems.length - 1) gridIndex++;
		}
		else if (k === 37) {
			if (gridIndex % cols === 0 || gridIndex === 0) {
				if (currentCategoryId === "search") return;
				focusArea = "catList";
			} else {
				gridIndex--;
			}
		}
		else if (k === 40) {
			if (gridIndex + cols < displayedItems.length) gridIndex += cols;
			else gridIndex = displayedItems.length - 1;
		}
		else if (k === 38) {
			if (gridIndex >= cols) {
				gridIndex -= cols;
			}
			else if (currentCategoryId === "search") {
				focusArea = "search";
				if (searchEl) searchEl.focus();
			}
		}
		else if (k === 13) {
			var item = displayedItems[gridIndex];
			if (!item) return;

			if (currentCategoryId === "search") {
				catIndex = 0;
			}

			if (item.is_season) {
				openSeason(item);
				return;
			}
			else if (item.is_episode) {
				playStream(item);
				return;
			}
			else {
				currentView = "streams";
				openDetails(item);
				return;
			}
		}
	}

	// ==========================================
	// DETAILS
	// ==========================================
	else if (focusArea === "details") {
		if (k === 39) {
			if (detailsFocus < 2) detailsFocus++;
		}
		else if (k === 37) {
			if (detailsFocus > 0) detailsFocus--;
		}
		else if (k === 13) {
			if (detailsFocus === 0) {
				var isSer = !!selectedItem.series_id || currentType === "series";

				if (isSer) {
					lastSeriesItem = selectedItem;
					if (detailsBox) detailsBox.style.display = "none";
					if (appArea) appArea.style.display = "block";
					openSeries(selectedItem.series_id || selectedItem.id);
				} else {
					playStream(selectedItem);
				}
			}
			else if (detailsFocus === 1) {
				toggleFav(selectedItem);
				var btnFav = document.getElementById("btnFav");
				if (btnFav) {
					btnFav.innerHTML = isFav(selectedItem.stream_id || selectedItem.series_id)
						? "🌟 Remover"
						: "⭐ Favoritar";
				}
			}
			else if (detailsFocus === 2) {
				closeDetails();
				focusArea = "catList";
			}
		}
	}

	// ==========================================
	// PLAYER
	// ==========================================
	else if (focusArea === "player") {
		showControls();

		if (k === 13 || keyName === " ") {
			videoEl.paused ? videoEl.play() : videoEl.pause();
		}
		else if (k === 37) {
			videoEl.currentTime = Math.max(0, videoEl.currentTime - 30);
		}
		else if (k === 39) {
			videoEl.currentTime = Math.min(videoEl.duration, videoEl.currentTime + 30);
		}
	}

	// ==========================================
	// POPUP SAIR
	// ==========================================
	else if (focusArea === "exitPopup") {
		if (k === 37 || k === 39) {
			window.exitFocus = window.exitFocus === 0 ? 1 : 0;
		}
		else if (k === 13) {
			if (window.exitFocus === 0) {
				try {
					tizen.application.getCurrentApplication().exit();
				} catch (e) {
					window.close();
				}
			} else {
				var popup3 = document.getElementById("exitPopup");
				if (popup3) popup3.style.display = "none";
				focusArea = window.telaAntesDeSair || "login";
			}
		}

		var btns = document.querySelectorAll(".exit-btn");
		if (btns.length > 0) {
			btns[0].style.background = "#333";
			btns[1].style.background = "#333";
			btns[window.exitFocus].style.background = "#007bff";
		}
		return;
	}

	updateFocus();
}, true);
// ==========================================
// MÁGICA DO PLAYER (Barra de Progresso)
// ==========================================
var controlsTimeout;
var playerControls = document.getElementById("playerControls");
var progressBar = document.getElementById("progressBar");
var currentTimeTxt = document.getElementById("currentTimeTxt");
var totalTimeTxt = document.getElementById("totalTimeTxt");

function formatTime(seconds) {
	if (isNaN(seconds))
		return "00:00:00";
	var h = Math.floor(seconds / 3600);
	var m = Math.floor((seconds % 3600) / 60);
	var s = Math.floor(seconds % 60);
	return (h < 10 ? "0" + h : h) + ":" + (m < 10 ? "0" + m : m) + ":"
			+ (s < 10 ? "0" + s : s);
}

// Ouve o vídeo tocando e atualiza a barra vermelha
videoEl.addEventListener("timeupdate", function() {
	if (!videoEl.duration)
		return;
	var percentage = (videoEl.currentTime / videoEl.duration) * 100;
	if (progressBar)
		progressBar.style.width = percentage + "%";
	if (currentTimeTxt)
		currentTimeTxt.textContent = formatTime(videoEl.currentTime);
	if (totalTimeTxt)
		totalTimeTxt.textContent = formatTime(videoEl.duration);
});

// Mostra a barra na TV e esconde depois de 4 segundos
function showControls() {
	if (!playerControls)
		return;
	playerControls.style.display = "block";
	clearTimeout(controlsTimeout);
	controlsTimeout = setTimeout(function() {
		playerControls.style.display = "none";
	}, 4000);
}
// ==========================================
// MÁGICA 2: Trava de Segurança LG/Samsung
// ==========================================
var isLG = navigator.userAgent.toLowerCase().indexOf("webos") > -1;
if (!isLG) {
	try {
		history.pushState({
			page : 'segura_tv'
		}, "Segura TV", "#ativo");
		window.addEventListener('popstate', function(event) {
			history.pushState({
				page : 'segura_tv'
			}, "Segura TV", "#ativo");
			if (focusArea === "player")
				stopPlayer();
			else if (focusArea === "details")
				closeDetails();
			else if (focusArea === "grid" || focusArea === "search")
				focusArea = "catList";
			else if (focusArea === "catList")
				focusArea = "sideMenu";
			updateFocus();
		});
	} catch (e) {
	}
}
// ==========================================
// MÁGICA 3: Preencher Login Automático (NetStream)
// ==========================================
window.onload = function() {
	var savedCode = localStorage.getItem("net_code");
	var savedUser = localStorage.getItem("net_user");
	var savedPass = localStorage.getItem("net_pass");

	if (savedCode && codeEl)
		codeEl.value = savedCode;
	if (savedUser)
		userEl.value = savedUser;
	if (savedPass)
		passEl.value = savedPass;

	if (savedCode && savedUser && savedPass) {
		loginFocus = 3;
	} else {
		loginFocus = 0;
	}

	updateFocus();
};